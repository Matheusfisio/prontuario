import { LocaleInput } from './index.js'

declare const allLocales: LocaleInput[]

export default allLocales
