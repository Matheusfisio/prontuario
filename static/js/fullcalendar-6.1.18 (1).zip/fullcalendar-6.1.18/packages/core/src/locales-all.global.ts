import { globalLocales } from './index.js'
import localesAll from './locales-all.js'

globalLocales.push(...localesAll)
