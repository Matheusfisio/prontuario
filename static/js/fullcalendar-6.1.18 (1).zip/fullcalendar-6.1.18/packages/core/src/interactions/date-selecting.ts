import { Hit } from './hit.js'

export type dateSelectionJoinTransformer = (hit0: Hit, hit1: Hit) => any
